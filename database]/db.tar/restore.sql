--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE grasp_electric;
--
-- Name: grasp_electric; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE grasp_electric WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE grasp_electric OWNER TO postgres;

\connect grasp_electric

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DocumentType" AS ENUM (
    'DATASHEET',
    'MANUAL',
    'CERTIFICATE',
    'CAD',
    'OTHER'
);


ALTER TYPE public."DocumentType" OWNER TO postgres;

--
-- Name: InquiryStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InquiryStatus" AS ENUM (
    'NEW',
    'READ',
    'REPLIED',
    'CLOSED'
);


ALTER TYPE public."InquiryStatus" OWNER TO postgres;

--
-- Name: InquiryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InquiryType" AS ENUM (
    'GENERAL',
    'SUPPORT',
    'PARTNERSHIP',
    'OTHER'
);


ALTER TYPE public."InquiryType" OWNER TO postgres;

--
-- Name: QuoteStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QuoteStatus" AS ENUM (
    'PENDING',
    'REVIEWED',
    'QUOTED',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED'
);


ALTER TYPE public."QuoteStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_sessions (
    id text NOT NULL,
    admin_user_id text NOT NULL,
    token_hash text NOT NULL,
    ip_address text,
    user_agent text,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.admin_sessions OWNER TO postgres;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.admin_users OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    code text,
    description text,
    image_url text,
    is_featured boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: category_specs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_specs (
    id text NOT NULL,
    category_id text NOT NULL,
    spec_value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.category_specs OWNER TO postgres;

--
-- Name: gallery_image_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gallery_image_products (
    id text NOT NULL,
    gallery_image_id text NOT NULL,
    product_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.gallery_image_products OWNER TO postgres;

--
-- Name: gallery_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gallery_images (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    image_url text NOT NULL,
    alt_text text,
    is_featured boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.gallery_images OWNER TO postgres;

--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inquiries (
    id text NOT NULL,
    inquiry_type public."InquiryType" DEFAULT 'GENERAL'::public."InquiryType" NOT NULL,
    company_name text,
    contact_name text NOT NULL,
    email text NOT NULL,
    phone text,
    subject text,
    message text NOT NULL,
    status public."InquiryStatus" DEFAULT 'NEW'::public."InquiryStatus" NOT NULL,
    internal_notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.inquiries OWNER TO postgres;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id text NOT NULL,
    product_id text NOT NULL,
    category_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: product_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_documents (
    id text NOT NULL,
    product_id text NOT NULL,
    name text NOT NULL,
    document_url text NOT NULL,
    document_type public."DocumentType" DEFAULT 'OTHER'::public."DocumentType" NOT NULL,
    file_size_bytes integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_documents OWNER TO postgres;

--
-- Name: product_dynamic_specs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_dynamic_specs (
    id text NOT NULL,
    product_id text NOT NULL,
    spec_key text NOT NULL,
    spec_value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.product_dynamic_specs OWNER TO postgres;

--
-- Name: product_features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_features (
    id text NOT NULL,
    product_id text NOT NULL,
    feature_text text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.product_features OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    product_id text NOT NULL,
    variant_id text,
    image_url text NOT NULL,
    alt_text text,
    is_primary boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variants (
    id text NOT NULL,
    product_id text NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    spec_dimensions text,
    spec_weight text,
    stock_quantity integer DEFAULT 0 NOT NULL,
    low_stock_threshold integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.product_variants OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    category_id text,
    name text NOT NULL,
    slug text NOT NULL,
    code text,
    description text,
    full_description text,
    spec_material text,
    spec_ip_rating text,
    spec_flammability text,
    spec_color text,
    spec_door_type text,
    spec_mounting text,
    spec_temperature_range text,
    is_featured boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: quote_request_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_request_items (
    id text NOT NULL,
    quote_request_id text NOT NULL,
    product_id text NOT NULL,
    variant_id text,
    quantity integer DEFAULT 1 NOT NULL,
    quoted_unit_price numeric(12,2),
    quoted_total numeric(12,2),
    notes text
);


ALTER TABLE public.quote_request_items OWNER TO postgres;

--
-- Name: quote_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_requests (
    id text NOT NULL,
    request_number text NOT NULL,
    status public."QuoteStatus" DEFAULT 'PENDING'::public."QuoteStatus" NOT NULL,
    company_name text NOT NULL,
    contact_name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text,
    quoted_at timestamp(3) without time zone,
    quote_valid_until timestamp(3) without time zone,
    total_quoted_amount numeric(12,2),
    currency text DEFAULT 'INR'::text NOT NULL,
    internal_notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quote_requests OWNER TO postgres;

--
-- Name: quote_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_status_history (
    id text NOT NULL,
    quote_request_id text NOT NULL,
    old_status public."QuoteStatus",
    new_status public."QuoteStatus" NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.quote_status_history OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_sessions (id, admin_user_id, token_hash, ip_address, user_agent, expires_at, created_at) FROM stdin;
\.
COPY public.admin_sessions (id, admin_user_id, token_hash, ip_address, user_agent, expires_at, created_at) FROM '$$PATH$$/4999.dat';

--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_users (id, email, password_hash, name, is_active, last_login_at, created_at, updated_at) FROM stdin;
\.
COPY public.admin_users (id, email, password_hash, name, is_active, last_login_at, created_at, updated_at) FROM '$$PATH$$/4998.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, code, description, image_url, is_featured, sort_order, created_at, updated_at) FROM stdin;
\.
COPY public.categories (id, name, slug, code, description, image_url, is_featured, sort_order, created_at, updated_at) FROM '$$PATH$$/5000.dat';

--
-- Data for Name: category_specs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_specs (id, category_id, spec_value, sort_order) FROM stdin;
\.
COPY public.category_specs (id, category_id, spec_value, sort_order) FROM '$$PATH$$/5001.dat';

--
-- Data for Name: gallery_image_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gallery_image_products (id, gallery_image_id, product_id, created_at) FROM stdin;
\.
COPY public.gallery_image_products (id, gallery_image_id, product_id, created_at) FROM '$$PATH$$/5015.dat';

--
-- Data for Name: gallery_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gallery_images (id, title, description, image_url, alt_text, is_featured, is_active, sort_order, created_at, updated_at) FROM stdin;
\.
COPY public.gallery_images (id, title, description, image_url, alt_text, is_featured, is_active, sort_order, created_at, updated_at) FROM '$$PATH$$/5014.dat';

--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inquiries (id, inquiry_type, company_name, contact_name, email, phone, subject, message, status, internal_notes, created_at, updated_at) FROM stdin;
\.
COPY public.inquiries (id, inquiry_type, company_name, contact_name, email, phone, subject, message, status, internal_notes, created_at, updated_at) FROM '$$PATH$$/5011.dat';

--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, product_id, category_id, created_at) FROM stdin;
\.
COPY public.product_categories (id, product_id, category_id, created_at) FROM '$$PATH$$/5013.dat';

--
-- Data for Name: product_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_documents (id, product_id, name, document_url, document_type, file_size_bytes, created_at) FROM stdin;
\.
COPY public.product_documents (id, product_id, name, document_url, document_type, file_size_bytes, created_at) FROM '$$PATH$$/5005.dat';

--
-- Data for Name: product_dynamic_specs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_dynamic_specs (id, product_id, spec_key, spec_value, sort_order) FROM stdin;
\.
COPY public.product_dynamic_specs (id, product_id, spec_key, spec_value, sort_order) FROM '$$PATH$$/5007.dat';

--
-- Data for Name: product_features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_features (id, product_id, feature_text, sort_order) FROM stdin;
\.
COPY public.product_features (id, product_id, feature_text, sort_order) FROM '$$PATH$$/5006.dat';

--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, product_id, variant_id, image_url, alt_text, is_primary, sort_order, created_at) FROM stdin;
\.
COPY public.product_images (id, product_id, variant_id, image_url, alt_text, is_primary, sort_order, created_at) FROM '$$PATH$$/5004.dat';

--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variants (id, product_id, sku, name, spec_dimensions, spec_weight, stock_quantity, low_stock_threshold, is_active, sort_order, created_at, updated_at) FROM stdin;
\.
COPY public.product_variants (id, product_id, sku, name, spec_dimensions, spec_weight, stock_quantity, low_stock_threshold, is_active, sort_order, created_at, updated_at) FROM '$$PATH$$/5003.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, category_id, name, slug, code, description, full_description, spec_material, spec_ip_rating, spec_flammability, spec_color, spec_door_type, spec_mounting, spec_temperature_range, is_featured, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.products (id, category_id, name, slug, code, description, full_description, spec_material, spec_ip_rating, spec_flammability, spec_color, spec_door_type, spec_mounting, spec_temperature_range, is_featured, is_active, created_at, updated_at) FROM '$$PATH$$/5002.dat';

--
-- Data for Name: quote_request_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_request_items (id, quote_request_id, product_id, variant_id, quantity, quoted_unit_price, quoted_total, notes) FROM stdin;
\.
COPY public.quote_request_items (id, quote_request_id, product_id, variant_id, quantity, quoted_unit_price, quoted_total, notes) FROM '$$PATH$$/5009.dat';

--
-- Data for Name: quote_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_requests (id, request_number, status, company_name, contact_name, email, phone, message, quoted_at, quote_valid_until, total_quoted_amount, currency, internal_notes, created_at, updated_at) FROM stdin;
\.
COPY public.quote_requests (id, request_number, status, company_name, contact_name, email, phone, message, quoted_at, quote_valid_until, total_quoted_amount, currency, internal_notes, created_at, updated_at) FROM '$$PATH$$/5008.dat';

--
-- Data for Name: quote_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_status_history (id, quote_request_id, old_status, new_status, notes, created_at) FROM stdin;
\.
COPY public.quote_status_history (id, quote_request_id, old_status, new_status, notes, created_at) FROM '$$PATH$$/5010.dat';

--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, key, value, created_at, updated_at) FROM stdin;
\.
COPY public.settings (id, key, value, created_at, updated_at) FROM '$$PATH$$/5012.dat';

--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_specs category_specs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_specs
    ADD CONSTRAINT category_specs_pkey PRIMARY KEY (id);


--
-- Name: gallery_image_products gallery_image_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_image_products
    ADD CONSTRAINT gallery_image_products_pkey PRIMARY KEY (id);


--
-- Name: gallery_images gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_pkey PRIMARY KEY (id);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_documents product_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_documents
    ADD CONSTRAINT product_documents_pkey PRIMARY KEY (id);


--
-- Name: product_dynamic_specs product_dynamic_specs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_dynamic_specs
    ADD CONSTRAINT product_dynamic_specs_pkey PRIMARY KEY (id);


--
-- Name: product_features product_features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_features
    ADD CONSTRAINT product_features_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quote_request_items quote_request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_request_items
    ADD CONSTRAINT quote_request_items_pkey PRIMARY KEY (id);


--
-- Name: quote_requests quote_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_requests
    ADD CONSTRAINT quote_requests_pkey PRIMARY KEY (id);


--
-- Name: quote_status_history quote_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_status_history
    ADD CONSTRAINT quote_status_history_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: admin_sessions_admin_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_sessions_admin_user_id_idx ON public.admin_sessions USING btree (admin_user_id);


--
-- Name: admin_sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_sessions_expires_at_idx ON public.admin_sessions USING btree (expires_at);


--
-- Name: admin_sessions_token_hash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX admin_sessions_token_hash_key ON public.admin_sessions USING btree (token_hash);


--
-- Name: admin_users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX admin_users_email_key ON public.admin_users USING btree (email);


--
-- Name: categories_is_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX categories_is_featured_idx ON public.categories USING btree (is_featured);


--
-- Name: categories_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX categories_slug_key ON public.categories USING btree (slug);


--
-- Name: categories_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX categories_sort_order_idx ON public.categories USING btree (sort_order);


--
-- Name: category_specs_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX category_specs_category_id_idx ON public.category_specs USING btree (category_id);


--
-- Name: gallery_image_products_gallery_image_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gallery_image_products_gallery_image_id_idx ON public.gallery_image_products USING btree (gallery_image_id);


--
-- Name: gallery_image_products_gallery_image_id_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX gallery_image_products_gallery_image_id_product_id_key ON public.gallery_image_products USING btree (gallery_image_id, product_id);


--
-- Name: gallery_image_products_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gallery_image_products_product_id_idx ON public.gallery_image_products USING btree (product_id);


--
-- Name: gallery_images_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gallery_images_is_active_idx ON public.gallery_images USING btree (is_active);


--
-- Name: gallery_images_is_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gallery_images_is_featured_idx ON public.gallery_images USING btree (is_featured);


--
-- Name: gallery_images_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX gallery_images_sort_order_idx ON public.gallery_images USING btree (sort_order);


--
-- Name: inquiries_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inquiries_created_at_idx ON public.inquiries USING btree (created_at DESC);


--
-- Name: inquiries_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inquiries_email_idx ON public.inquiries USING btree (email);


--
-- Name: inquiries_inquiry_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inquiries_inquiry_type_idx ON public.inquiries USING btree (inquiry_type);


--
-- Name: inquiries_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inquiries_status_idx ON public.inquiries USING btree (status);


--
-- Name: product_categories_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_categories_category_id_idx ON public.product_categories USING btree (category_id);


--
-- Name: product_categories_product_id_category_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_categories_product_id_category_id_key ON public.product_categories USING btree (product_id, category_id);


--
-- Name: product_categories_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_categories_product_id_idx ON public.product_categories USING btree (product_id);


--
-- Name: product_documents_document_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_documents_document_type_idx ON public.product_documents USING btree (document_type);


--
-- Name: product_documents_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_documents_product_id_idx ON public.product_documents USING btree (product_id);


--
-- Name: product_dynamic_specs_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_dynamic_specs_product_id_idx ON public.product_dynamic_specs USING btree (product_id);


--
-- Name: product_dynamic_specs_product_id_spec_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_dynamic_specs_product_id_spec_key_key ON public.product_dynamic_specs USING btree (product_id, spec_key);


--
-- Name: product_features_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_features_product_id_idx ON public.product_features USING btree (product_id);


--
-- Name: product_images_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_images_product_id_idx ON public.product_images USING btree (product_id);


--
-- Name: product_images_variant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_images_variant_id_idx ON public.product_images USING btree (variant_id);


--
-- Name: product_variants_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_variants_product_id_idx ON public.product_variants USING btree (product_id);


--
-- Name: product_variants_sku_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_variants_sku_key ON public.product_variants USING btree (sku);


--
-- Name: product_variants_stock_quantity_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_variants_stock_quantity_idx ON public.product_variants USING btree (stock_quantity);


--
-- Name: products_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX products_category_id_idx ON public.products USING btree (category_id);


--
-- Name: products_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX products_is_active_idx ON public.products USING btree (is_active);


--
-- Name: products_is_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX products_is_featured_idx ON public.products USING btree (is_featured);


--
-- Name: products_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX products_slug_key ON public.products USING btree (slug);


--
-- Name: quote_request_items_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quote_request_items_product_id_idx ON public.quote_request_items USING btree (product_id);


--
-- Name: quote_request_items_quote_request_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quote_request_items_quote_request_id_idx ON public.quote_request_items USING btree (quote_request_id);


--
-- Name: quote_requests_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quote_requests_created_at_idx ON public.quote_requests USING btree (created_at DESC);


--
-- Name: quote_requests_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quote_requests_email_idx ON public.quote_requests USING btree (email);


--
-- Name: quote_requests_request_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX quote_requests_request_number_key ON public.quote_requests USING btree (request_number);


--
-- Name: quote_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quote_requests_status_idx ON public.quote_requests USING btree (status);


--
-- Name: quote_status_history_quote_request_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quote_status_history_quote_request_id_idx ON public.quote_status_history USING btree (quote_request_id);


--
-- Name: settings_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX settings_key_key ON public.settings USING btree (key);


--
-- Name: admin_sessions admin_sessions_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.admin_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: category_specs category_specs_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_specs
    ADD CONSTRAINT category_specs_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gallery_image_products gallery_image_products_gallery_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_image_products
    ADD CONSTRAINT gallery_image_products_gallery_image_id_fkey FOREIGN KEY (gallery_image_id) REFERENCES public.gallery_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gallery_image_products gallery_image_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_image_products
    ADD CONSTRAINT gallery_image_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_categories product_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_categories product_categories_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_documents product_documents_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_documents
    ADD CONSTRAINT product_documents_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_dynamic_specs product_dynamic_specs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_dynamic_specs
    ADD CONSTRAINT product_dynamic_specs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_features product_features_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_features
    ADD CONSTRAINT product_features_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quote_request_items quote_request_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_request_items
    ADD CONSTRAINT quote_request_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quote_request_items quote_request_items_quote_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_request_items
    ADD CONSTRAINT quote_request_items_quote_request_id_fkey FOREIGN KEY (quote_request_id) REFERENCES public.quote_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quote_request_items quote_request_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_request_items
    ADD CONSTRAINT quote_request_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quote_status_history quote_status_history_quote_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_status_history
    ADD CONSTRAINT quote_status_history_quote_request_id_fkey FOREIGN KEY (quote_request_id) REFERENCES public.quote_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

